<?php
/**
* Affiliates
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright © Copyright 2016 - All right reserved
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  FMM Modules
* @package   affiliates
*/

if (!defined('_PS_VERSION_'))
exit;

include_once(dirname(__FILE__).'/models/Affiliation.php');
include_once(dirname(__FILE__).'/models/Referrals.php');
include_once(dirname(__FILE__).'/models/Rules.php');
include_once(dirname(__FILE__).'/models/Levels.php');
include_once(dirname(__FILE__).'/models/Rewards.php');
include_once(dirname(__FILE__).'/models/Payment.php');
include_once(dirname(__FILE__).'/models/PaymentDetails.php');
include_once(dirname(__FILE__).'/models/Affiliate_Invitations.php');
class Affiliates extends Module
{
	private $tab_parent_class	= null;
	private $tab_class			= 'AdminAffiliation';
	public function __construct()
	{
		$this->name			= 'affiliates';
		$this->tab			= 'advertising_marketing';
		$this->version		= '1.2.0';
		$this->author		= 'FMM Modules';
		$this->bootstrap	= true;
		$this->module_key = '76b627baaa2c580cf2ee0bc281786da7';
		parent::__construct();
		$this->displayName = $this->l('Affiliates');
		$this->description = $this->l('This module provides affiliate program to your customers.');
	}

	public function install()
	{
		if (!Affiliation::existsTab($this->tab_class))
		{
			if (!$this->addTab($this->tab_class, 0))
			return false;
		}

		if (!parent::install()
			|| !$this->registerHook('footer')
			|| !$this->registerHook('displayHeader')
			|| !$this->registerHook('actionCustomerAccountAdd')
			|| !$this->registerHook('actionOrderStatusPostUpdate')
			|| !$this->registerHook('displayCustomerAccount')
			|| !$this->registerHook('ActionAuthentication')
			|| !$this->registerHook('displayBackOfficeHeader')
			|| !$this->registerHook('newOrder')
			|| !$this->installConfigurations()
			|| !$this->createAffiliateGroup()
			|| !$this->installDb())
			return false;
		return true;
	}

	public function uninstall()
	{
		if (!$this->removeTab($this->tab_class))
			return false;

		if (!parent::uninstall()
			|| !$this->unregisterHook('footer')
			|| !$this->unregisterHook('displayHeader')
			|| !$this->unregisterHook('actionCustomerAccountAdd')
			|| !$this->unregisterHook('actionOrderStatusPostUpdate')
			|| !$this->unregisterHook('displayBackOfficeHeader')
			|| !$this->unregisterHook('ActionAuthentication')
			|| !$this->unregisterHook('displayCustomerAccount')
			|| !$this->unregisterHook('newOrder')
			|| !$this->unInstallConfiguration()
			|| !$this->deleteAffiliateGroup()
			|| !$this->deleteDiscountVoucher()
			|| !$this->uninstallDb())
			return false;
		return true;
	}

	public function installDb()
	{
		Affiliation::createTable();
		Referrals::createTable();
		Rules::createTable();
		Levels::createTable();
		Rewards::createTable();
		Payment::createTable();
		PaymentDetails::createTable();
		AffiliateInvitations::createTable();
		return true;
	}

	public function uninstallDb()
	{
		Affiliation::removeTable();
		Referrals::removeTable();
		Rules::removeTable();
		Levels::removeTable();
		Rewards::removeTable();
		Payment::removeTable();
		PaymentDetails::removeTable();
		AffiliateInvitations::removeTable();
		return true;
	}

	private function installConfigurations()
	{
		Configuration::updateValue('AFFILIATE_GROUPS', (int)Configuration::get('PS_CUSTOMER_GROUP'));
		Configuration::updateValue('AFFILIATE_CONDITION', (int)Configuration::get('PS_CONDITIONS_CMS_ID'));
		Configuration::updateValue('PAYMENT_METHOD', '2');
		Configuration::updateValue('APPROVAL_STATES', '2');
		Configuration::updateValue('CANCEL_STATES', '6');
		Configuration::updateValue('MINIMUM_AMOUNT', 50);
		Configuration::updateValue('PAYMENT_DELAY_TIME', 45);
		Configuration::updateValue('REFERAK_KEY_LEN', 16);
		Configuration::updateValue('DELAY_TYPE', 'd');
		Configuration::updateValue('ID_AFFILIATE_DISCOUNT_RULE', 0);
		Configuration::updateValue('AFFILIATE_FACEBOOK', 1);
		Configuration::updateValue('AFFILIATE_TWITTER', 1);
		Configuration::updateValue('AFFILIATE_GOOGLE', 1);
		Configuration::updateValue('AFFILIATE_DIGG', 1);
		Configuration::updateValue('REFERRAL_DISCOUNT_STATUS', 0);
		Configuration::updateValue('PAYPAL_MODE', 1);
		return true;
	}

	private function unInstallConfiguration()
	{
		Configuration::deleteByName('AFFILIATE_GROUPS');
		Configuration::deleteByName('AFFILIATE_CONDITION');
		Configuration::deleteByName('PAYMENT_METHOD');
		Configuration::deleteByName('MINIMUM_AMOUNT');
		Configuration::deleteByName('PAYMENT_DELAY_TIME');
		Configuration::deleteByName('REFERAK_KEY_LEN');
		Configuration::deleteByName('DELAY_TYPE');
		Configuration::deleteByName('APPROVAL_STATES');
		Configuration::deleteByName('CANCEL_STATES');
		Configuration::deleteByName('AFFILIATE_FACEBOOK');
		Configuration::deleteByName('AFFILIATE_TWITTER');
		Configuration::deleteByName('AFFILIATE_GOOGLE');
		Configuration::deleteByName('AFFILIATE_DIGG');
		Configuration::deleteByName('referral_welcom_msg');
		Configuration::deleteByName('REFERRAL_DISCOUNT_STATUS');
		Configuration::deleteByName('REFERRAL_DISCOUNT_TYPE');
		Configuration::deleteByName('REFERRAL_DISCOUNT_VALUE');
		Configuration::deleteByName('REFERRAL_DISCOUNT_CURRENCY');
		Configuration::deleteByName('PAYPAL_MODE');
		Configuration::deleteByName('PAYPAL_EMAIL');
		Configuration::deleteByName('PAYPAL_USERNAME');
		Configuration::deleteByName('PAYPAL_API_PASSWORD');
		Configuration::deleteByName('PAYPAL_API_SIGNATURE');
		Configuration::deleteByName('PAYPAL_APP_ID');
		return true;
	}

	private function addTab($tab_class)
	{
		$tab = new Tab();
		$tab->class_name = $tab_class;
		$tab->id_parent = 0;
		$tab->module = $this->name;
		$tab->name[(int)Configuration::get('PS_LANG_DEFAULT')] = $this->l('Affiliates');
		$tab->add();

		$subtab1 = new Tab();
		$subtab1->class_name = 'AdminAffiliates';
		$subtab1->id_parent = $tab->id;
		$subtab1->module = $this->name;
		$subtab1->name[(int)Configuration::get('PS_LANG_DEFAULT')] = $this->l('Manage Affiliates');
		$subtab1->add();

		$subtab2 = new Tab();
		$subtab2->class_name = 'AdminReferrals';
		$subtab2->id_parent = $tab->id;
		$subtab2->module = $this->name;
		$subtab2->name[(int)Configuration::get('PS_LANG_DEFAULT')] = $this->l('Referrals');
		$subtab2->add();

		$subtab3 = new Tab();
		$subtab3->class_name = 'AdminLevels';
		$subtab3->id_parent = $tab->id;
		$subtab3->module = $this->name;
		$subtab3->name[(int)(Configuration::get('PS_LANG_DEFAULT'))] = $this->l('Order Reward');
		$subtab3->add();

		$subtab4 = new Tab();
		$subtab4->class_name = 'AdminRules';
		$subtab4->id_parent = $tab->id;
		$subtab4->module = $this->name;
		$subtab4->name[(int)Configuration::get('PS_LANG_DEFAULT')] = $this->l('Rules');
		$subtab4->add();

		$subtab5 = new Tab();
		$subtab5->class_name = 'AdminPayments';
		$subtab5->id_parent = $tab->id;
		$subtab5->module = $this->name;
		$subtab5->name[(int)(Configuration::get('PS_LANG_DEFAULT'))] = $this->l('Withdraw Requests');
		$subtab5->add();

		$subtab6 = new Tab();
		$subtab6->class_name = 'AdminAffiliateStates';
		$subtab6->id_parent = $tab->id;
		$subtab6->module = $this->name;
		$subtab6->name[(int)(Configuration::get('PS_LANG_DEFAULT'))] = $this->l('Statistics');
		$subtab6->add();
		return true;
	}

	private function removeTab($tabClass)
	{
		$idTab = Tab::getIdFromClassName($tabClass);
		if ($idTab != 0)
		{
			$tab = new Tab($idTab);
			$tab->delete();
			return true;
		}
		return false;
	}

	public function hookDisplayBackOfficeHeader()
	{
		$this->context->controller->addCSS($this->_path.'views/css/admin.css');
		if ($this->context->controller->controller_name == 'AdminLevels')
			$this->context->controller->addJS($this->_path.'views/js/affiliate_admin.js');

		if ($this->context->controller->controller_name == 'AdminModules' && Tools::getValue('configure') == 'affiliates')
		{
			$this->context->controller->addJquery();
			$this->context->controller->addJS(array(
				_PS_JS_DIR_.'tiny_mce/tiny_mce.js',
				_PS_JS_DIR_.'admin/tinymce.inc.js',
				_PS_JS_DIR_.'admin.js',
				_PS_JS_DIR_.'admin/product.js',
				));
		}
		// show alerts
		$this->context->smarty->assign(array(
			'count' => abs(Affiliation::countAffiliates()),
			'controller' => $this->context->controller->controller_name,
			'id_affiliate' => (Tools::getValue('id_affiliate') ? (int)Tools::getValue('id_affiliate') : '0'),
			'key_len'	=> (Configuration::get('REFERAK_KEY_LEN') ? (int)Configuration::get('REFERAK_KEY_LEN') : 16),
			'ref_key'	=> ((Tools::getValue('id_affiliate')) ? Affiliation::getRefKey((int)Tools::getValue('id_affiliate')) : ''),
			));
		return $this->display(__FILE__, 'views/templates/admin/alerts.tpl');
	}

	public function hookDisplayHeader()
	{
		if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true)
			$this->context->controller->addJqueryPlugin('fancybox');
	}
	
	public function hookFooter()
	{
		$shops = Affiliation::getAssocShops();
		if ((Shop::isFeatureActive() && isset($shops) && in_array($this->context->shop->id, $shops)) || !Shop::isFeatureActive() || empty($shops))
		{
			$ref = (string)Tools::getValue('ref');
			$src = (string)Tools::getValue('src');
			$this->context->controller->addJqueryPlugin('fancybox');
			$this->context->controller->addCSS($this->_path.'views/css/affiliate_tabcontent.css');
			$this->context->controller->addJS($this->_path.'views/js/affiliate_tabcontent.js');
			$sp = false;
			$res = false;
			if (!empty($ref) && !Affiliation::affiliateExists($ref, $this->context->cookie->id_shop))
			{
				$sp = true;
				$this->context->controller->errors[] = Tools::displayError('Invalid referral link.');
			}
			// referrals followed using share link
			elseif (!empty($ref) && $src == 'link' && Affiliation::affiliateExists($ref))
			{
				$sp = true;
				$self_ref = Affiliation::SelfRef((int)$this->context->customer->id, (int)$this->context->cookie->id_guest);
				if (Referrals::isGuestReferralExists((int)$this->context->cookie->id_guest))
					$this->context->controller->errors[] = Tools::displayError('You have already been referred.');
				elseif (isset($self_ref) && $self_ref == $ref)
					$this->context->controller->errors[] = Tools::displayError('You cannot add yourself as a referral.');
				else
				{
					$aff_customer = Affiliation::getAffiliateByRef($ref);
					if (isset($aff_customer))
					{
						$referral = new Referrals();
						$referral->id_affiliate = (int)$aff_customer['id_affiliate'];
						$referral->id_customer = (int)$this->context->cookie->id_customer;
						$referral->id_guest = (int)$this->context->cookie->id_guest;
						$referral->active = 1;
						// $referral->approved = 0;
						$referral->source = 'link';
						$referral->date_from = date('Y-m-d H:i:s');
						$referral->date_add = date('Y-m-d H:i:s');

						if (!$referral->add())
							$this->context->controller->errors[] = Tools::displayError('Operation failed, something went wrong.');
						else
							$res = true;
					}
				}
			}
			// referrals followed using email
			elseif (!empty($ref) && $src == 'email' && Affiliation::affiliateExists($ref))
			{
				$sp = true;
				$token = (string)Tools::getValue('t');
				$id_invitation = (int)Tools::getValue('inv');

				if (AffiliateInvitations::isIdExists($id_invitation))
				{
					$ref_guest = new AffiliateInvitations((int)$id_invitation);
					$hash = md5($ref_guest->email);
					if ((isset($this->context->customer) && isset($this->context->customer->email) && $token != md5($this->context->customer->email)))
						$this->context->controller->errors[] = Tools::displayError('Operation failed, mismatch email');
					elseif (($hash == $token))
					{
						$referral = new Referrals();
						$referral->id_affiliate = (int)$ref_guest->id_affiliate;
						$referral->id_customer = (int)$this->context->customer->id;
						$referral->id_guest = (int)$this->context->cookie->id_guest;
						$referral->active = 1;
						// $referral->approved = 0;
						$referral->source = 'email';
						$referral->date_from = date('Y-m-d H:i:s');
						$referral->date_add = date('Y-m-d H:i:s');
						if ($referral->add())
						{
							$res = true;
							$ref_guest->id_referral = $referral->id;
							$ref_guest->update();
						}
						else
							$this->context->controller->errors[] = Tools::displayError('Operation failed, something went wrong.');
					}
					else
						$this->context->controller->errors[] = Tools::displayError('Operation failed, invalid token');
				}
			}

			if ($sp != false)
			{
				$discount = 0.00;
				$code = '';
				if (Configuration::get('REFERRAL_DISCOUNT_STATUS')
					&& (Configuration::get('ID_AFFILIATE_DISCOUNT_RULE') > 0)
					&& Affiliation::cartRuleExists(Configuration::get('ID_AFFILIATE_DISCOUNT_RULE')))
				{
					$coupon = new CartRule((int)Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'));
					$coupon->quantity = ($coupon->quantity <= 0)? 1000 : $coupon->quantity;
					$coupon->date_to = (strtotime($coupon->date_to) <= strtotime(date('Y:m:d H:i:s')))? date('Y-m-d H:i:s', strtotime('+5 years')): $coupon->date_to;
					$code = $coupon->code;
					if ($coupon->update())
						$discount = Tools::ps_round((float)Configuration::get('REFERRAL_DISCOUNT_VALUE'));
				}

				$this->context->smarty->assign(array(
					'errors' => $this->context->controller->errors,
					'result' => (int)$res,
					'welcom_message' => Configuration::get('referral_welcom_msg', $this->context->language->id),
					'discount' => $discount,
					'code' => $code,
					'ps_version' => _PS_VERSION_,
					'discount_type' => (string)Configuration::get('REFERRAL_DISCOUNT_TYPE')
				));
				if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true)
				{
					$this->context->smarty->assign(array('base_dir' => _PS_BASE_URL_.__PS_BASE_URI__));
					return $this->display(__FILE__, 'views/templates/hook/aff_footer-17.tpl');
				}
				else
					return $this->display(__FILE__, 'views/templates/hook/aff_footer.tpl');
			}
		}
	}

	public function hookDisplayCustomerAccount()
	{
		$affiliate_groups = (Configuration::get('AFFILIATE_GROUPS') ? explode(',', Configuration::get('AFFILIATE_GROUPS')) : '');
		$this->context->smarty->assign('ps_version', _PS_VERSION_);
		$ps_17 = (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) ? 1 : 0;
		$this->context->smarty->assign('ps_17', (int)$ps_17);
		$shops = Affiliation::getAssocShops();
		if ((Shop::isFeatureActive() && isset($shops) && in_array($this->context->shop->id, $shops)) || !Shop::isFeatureActive() || empty($shops))
		{
			if (isset($affiliate_groups) && $affiliate_groups && in_array($this->context->customer->id_default_group, $affiliate_groups))
				return $this->display(__FILE__, 'my-account.tpl');
			elseif (empty($affiliate_groups))
				return $this->display(__FILE__, 'my-account.tpl');
		}
	}

	public function hookActionCustomerAccountAdd($params)
	{
		$multishop = false;
		$shops = Affiliation::getAssocShops();
		if ((Shop::isFeatureActive() && isset($shops) && in_array($this->context->shop->id, $shops)) || !Shop::isFeatureActive() || empty($shops))
			$multishop = true;

		if ($multishop && isset($params) && isset($params['newCustomer']))
		{
			$id_customer = (int)$params['newCustomer']->id;
			$id_guest = (int)$params['cookie']->id_guest;
			$email = (string)$params['newCustomer']->email;
			$reward_value = 0;

			$id_referral = ((AffiliateInvitations::getRefIdByEmail($email))? AffiliateInvitations::getRefIdByEmail($email) : Referrals::getReferralsGuestById($id_guest));
			if (!empty($id_referral) && $id_referral)
			{
				$referral = new Referrals((int)$id_referral);
				$referral->id_customer = (int)$id_customer;
				$referral->id_guest = (int)$id_guest;

				$nbr_referrals = (int)Referrals::countAffiliateRefs($referral->id_affiliate);
				$id_rule = (int)Rules::getApplicableRuleId($nbr_referrals);
				$affiliate = new Affiliation((int)$referral->id_affiliate);
				if ((isset($id_rule) && $id_rule) && $affiliate->rule != $id_rule)
				{
					$rule = Rules::getRuleById($id_rule);
					$reward_value = (float)$rule['reg_reward_value'];
					$affiliate->rule = (int)$id_rule;
				}

				if ($referral->update())
				{
					if (isset($reward_value) && $reward_value > 0.00)
					{
						$reward = new Rewards();
						$reward->id_affiliate		= (int)$affiliate->id_affiliate;
						$reward->id_referral		= (int)$referral->id;
						$reward->id_customer		= (int)$affiliate->id_customer;
						$reward->id_guest			= (int)$affiliate->id_guest;
						$reward->reward_by_reg		= 1;
						$reward->reward_by_ord		= 0;
						$reward->reg_reward_value	= (float)$reward_value;
						$reward->ord_reward_value	= 0;
						$reward->is_paid			= 0;
						$reward->status 			= 'approved';
						$reward->pay_request		= 'not sent';
						$reward->reward_date		= date('Y-m-d H:i:s');

						if (!$reward->add() && !$affiliate->update())
							$this->context->controller->errors[] = Tools::displayError('Reward cannot awarded');
					}
				}
				else
					$this->context->controller->errors[] = Tools::displayError('Error referral association.');
			}
		}
	}

	public function hookNewOrder($params)
	{
		$id_customer = (int)$this->context->customer->id;
		$id_guest = (int)$this->context->cookie->id_guest;
		$order = $params['order'];

		$id_affiliate = Referrals::getAffiliateByCustomer($id_customer, $id_guest);
		$referral = Referrals::getReferralByCustomer($id_customer, $id_guest);

		$multishop = false;
		$shops = Affiliation::getAssocShops();
		if ((Shop::isFeatureActive() && isset($shops) && in_array($this->context->shop->id, $shops)) || !Shop::isFeatureActive() || empty($shops))
			$multishop = true;

		if ($multishop && isset($id_affiliate) && isset($referral) && $id_affiliate)
		{
			$reward_value = 0;
			$level = Levels::getDefaultLevel();
			$affiliate = new Affiliation((int)$id_affiliate);

			$total_order = 0;
			if ($level)
			{
				if ((int)$level['is_tax'])
					$total_order = $order->getTotalProductsWithTaxes();
				else
					$total_order = $order->getTotalProductsWithoutTaxes();

				if ($total_order >= $level['min_order_value'])
				{
					if ((int)$level['reward_type'] == 1)
					{
						$pc = ($level['reward_value'] / 100) * $total_order;
						$reward_value = (float)$pc;
					}
					else
						$reward_value = (float)$level['reward_value'];

					$reward = new Rewards();
					$reward->id_affiliate		= (int)$id_affiliate;
					$reward->id_referral		= (int)$referral['id_referral'];
					$reward->id_customer		= (int)$affiliate->id_customer;
					$reward->id_guest			= (int)$affiliate->id_guest;
					$reward->reward_by_reg		= 0;
					$reward->reward_by_ord		= 1;
					$reward->reg_reward_value	= 0;
					$reward->id_order			= (int)$order->id;
					$reward->ord_reward_value	= (float)$reward_value;
					$reward->status 			= 'pending';
					$reward->reward_date		= date('Y-m-d H:i:s');
					$reward->add();
				}
			}
		}
	}

	public function hookActionOrderStatusPostUpdate($params)
	{
		$multishop = false;
		$shops = Affiliation::getAssocShops();
		if ((Shop::isFeatureActive() && isset($shops) && in_array($this->context->shop->id, $shops)) || !Shop::isFeatureActive() || empty($shops))
			$multishop = true;
		//$order_state	= $params['newOrderStatus'];
		$id_order		= (int)Tools::getValue('id_order');
		//$order			= new Order((int)$id_order);
		$id_order_state = (int)Tools::getValue('id_order_state');
		$reward_data	= Rewards::getRewardByOrder($id_order);
		
		$approval_states = (Configuration::get('APPROVAL_STATES')? explode(',', Configuration::get('APPROVAL_STATES')) : array());
		$cancel_states = (Configuration::get('CANCEL_STATES')? explode(',', Configuration::get('CANCEL_STATES')) : array());

		if (!empty($reward_data) && $multishop)
		{
			// getting order state history
			$history = (Affiliation::getOrderStateHistory($id_order))? Affiliation::getOrderStateHistory($id_order) : array();

			$reward = new Rewards((int)$reward_data['id_reward']);
			if (!empty($approval_states) && in_array($id_order_state, $approval_states) && !in_array($id_order_state, $history))//empty($approval_history_exists))
				$reward->status = 'approved';
			elseif (!empty($cancel_states) && in_array($id_order_state, $cancel_states) && !in_array($id_order_state, $history))//empty($cancel_history_exists))
				$reward->status = 'cancel';

			if ($reward->update())
				Payment::deleteByReward($reward->id);
		}
	}

	public function getContent()
	{
		$current_index = $this->context->link->getAdminLink('AdminModules', false);
		$current_token = Tools::getAdminTokenLite('AdminModules');
		$action_url = $current_index.'&configure='.$this->name.'&token='.$current_token.'&tab_module='.$this->tab.'&module_name='.$this->name;

		$this->postProcess();
		return $this->displayConfigForm($action_url);
	}

	public function getConfigFieldsValues()
	{
		$languages = Language::getLanguages(false);
		$return = '';
		foreach ($languages as $lang)
			$return['referral_welcom_msg'][(int)$lang['id_lang']] = Tools::getValue('referral_welcom_msg'.(int)$lang['id_lang'], Configuration::get('referral_welcom_msg', (int)$lang['id_lang']));
		return $return;
	}

	private function displayConfigForm($action_url)
	{
		$groups = Group::getGroups((int)$this->context->language->id, true);

		$affiliate_groups = (Configuration::get('AFFILIATE_GROUPS')? explode(',', Configuration::get('AFFILIATE_GROUPS')) : '');
		$approval_states = (Configuration::get('APPROVAL_STATES')? explode(',', Configuration::get('APPROVAL_STATES')) : '');
		$cancel_states = (Configuration::get('CANCEL_STATES')) ? explode(',', Configuration::get('CANCEL_STATES')) : '';

		// List of CMS tabs
		$cms_tab = array();
		foreach (CMS::listCms($this->context->language->id) as $cms_file)
			$cms_tab[] = array('id' => $cms_file['id_cms'], 'name' => $cms_file['meta_title']);

		$shops = '';
		$selected_shops = '';
		$multishop = 0;
		if (Shop::isFeatureActive())
		{
			$multishop = 1;
			$shops = $this->renderShops();
			$selected_shops = (Affiliation::getAssocShops())? implode(',', Affiliation::getAssocShops()) :'';
		}
		$this->context->smarty->assign(array('shops' => $shops, 'selected_shops' => $selected_shops));

		$iso_tiny_mce = $this->context->language->iso_code;
		$iso_tiny_mce = (file_exists(_PS_JS_DIR_.'tiny_mce/langs/'.$iso_tiny_mce.'.js') ? $iso_tiny_mce : 'en');
		
		$this->smarty->assign(array(
			'currency'						=> $this->context->currency,
			'ps_version'					=> _PS_VERSION_,
			'multishop'						=> $multishop,
			'groups'						=> $groups,
			'action_url'					=> $action_url,
			'cms_tabs'						=> $cms_tab,
			'affiliate_groups'				=> $affiliate_groups,
			'approval_states'				=> $approval_states,
			'cancel_states'					=> $cancel_states,
			'iso_tiny_mce'					=> $iso_tiny_mce,
			'MINIMUM_AMOUNT' 				=> Configuration::get('MINIMUM_AMOUNT'),
			'PAYMENT_DELAY_TIME'			=> Configuration::get('PAYMENT_DELAY_TIME'),
			'REFERAK_KEY_LEN'				=> (int)Configuration::get('REFERAK_KEY_LEN'),
			'PAYPAL_MODE'					=> Configuration::get('PAYPAL_MODE'),
			'PAYPAL_EMAIL'					=> Configuration::get('PAYPAL_EMAIL'),
			'PAYPAL_USERNAME'				=> Configuration::get('PAYPAL_USERNAME'),
			'PAYPAL_APP_ID'					=> Configuration::get('PAYPAL_APP_ID'),
			'PAYPAL_API_PASSWORD'			=> Configuration::get('PAYPAL_API_PASSWORD'),
			'PAYPAL_API_SIGNATURE'			=> Configuration::get('PAYPAL_API_SIGNATURE'),
			'referral_welcom_msg' 			=> $this->getConfigFieldsValues(),
			'REFERRAL_DISCOUNT_STATUS'		=> Configuration::get('REFERRAL_DISCOUNT_STATUS'),
			'REFERRAL_DISCOUNT_TYPE'		=> Configuration::get('REFERRAL_DISCOUNT_TYPE'),
			'REFERRAL_DISCOUNT_VALUE'		=> Configuration::get('REFERRAL_DISCOUNT_VALUE'),
			'REFERRAL_DISCOUNT_CURRENCY'	=> Configuration::get('REFERRAL_DISCOUNT_CURRENCY'),
			'AFFILIATE_FACEBOOK'			=> Configuration::get('AFFILIATE_FACEBOOK'),
			'AFFILIATE_TWITTER'				=> Configuration::get('AFFILIATE_TWITTER'),
			'AFFILIATE_GOOGLE'				=> Configuration::get('AFFILIATE_GOOGLE'),
			'AFFILIATE_DIGG'				=> Configuration::get('AFFILIATE_DIGG'),
			'states'						=> OrderState::getOrderStates($this->context->language->id),
			'currencies'					=> Currency::getCurrencies(false, true, true),
			'module'						=> new Affiliates(),
			'id_lang_default'				=> $this->context->language->id,
			'languages'						=> Language::getLanguages(false),
			'ad'							=> __PS_BASE_URI__.basename(_PS_ADMIN_DIR_),
			'id_lang'						=> $this->context->language->id,
			'PAYMENT_METHOD'				=> (Configuration::get('PAYMENT_METHOD')? explode(',', Configuration::get('PAYMENT_METHOD')): ''),
		));
		return	$this->display(__FILE__, 'form.tpl');
	}

	protected function postProcess()
	{
		if (Tools::isSubmit('saveSettings'))
		{
			$affiliate_groups = (Tools::getValue('affiliate_groups')) ? implode(',', Tools::getValue('affiliate_groups')) : '';
			$approval_states = (Tools::getValue('approval_states')) ? implode(',', Tools::getValue('approval_states')) : '';
			$cancel_states = (Tools::getValue('cancel_states')) ? implode(',', Tools::getValue('cancel_states')) : '';
			$pm_methods = Tools::getValue('PAYMENT_METHOD');

			Configuration::updateValue('AFFILIATE_GROUPS', $affiliate_groups);
			Configuration::updateValue('APPROVAL_STATES', $approval_states);
			Configuration::updateValue('CANCEL_STATES', $cancel_states);
			Configuration::updateValue('AFFILIATE_CONDITION', (int)Tools::getValue('AFFILIATE_CONDITION'));
			Configuration::updateValue('PAYMENT_METHOD', ($pm_methods? implode(',', $pm_methods): ''));

			if (!Validate::isFloat(Tools::getValue('MINIMUM_AMOUNT')))
				$this->context->controller->errors[] = $this->l('Inavlid minimum amount');
			if (!Validate::isInt(Tools::getValue('PAYMENT_DELAY_TIME')))
				$this->context->controller->errors[] = $this->l('Inavlid Payment holding time');
			if (!Validate::isInt(Tools::getValue('REFERAK_KEY_LEN')))
				$this->context->controller->errors[] = $this->l('Inavlid Referal Key length');
			if (isset($pm_methods) && isset($pm_methods['paypal']) && !Validate::isEmail(Tools::getValue('PAYPAL_EMAIL')))
				$this->context->controller->errors[] = $this->l('Inavlid paypal email');
			else
			{
				Configuration::updateValue('MINIMUM_AMOUNT', (float)Tools::getValue('MINIMUM_AMOUNT'));
				Configuration::updateValue('PAYMENT_DELAY_TIME', (int)Tools::getValue('PAYMENT_DELAY_TIME'));
				Configuration::updateValue('REFERAK_KEY_LEN', (int)Tools::getValue('REFERAK_KEY_LEN'));
				Configuration::updateValue('PAYPAL_EMAIL', (string)Tools::getValue('PAYPAL_EMAIL'));
			}

			Configuration::updateValue('DELAY_TYPE', (string)Tools::getValue('DELAY_TYPE'));
			// PAYPAL API credentials
			Configuration::updateValue('PAYPAL_MODE', (int)Tools::getValue('PAYPAL_MODE'));
			Configuration::updateValue('PAYPAL_USERNAME', (string)Tools::getValue('PAYPAL_USERNAME'));
			Configuration::updateValue('PAYPAL_API_PASSWORD', (string)Tools::getValue('PAYPAL_API_PASSWORD'));
			Configuration::updateValue('PAYPAL_APP_ID', (string)Tools::getValue('PAYPAL_APP_ID'));
			Configuration::updateValue('PAYPAL_API_SIGNATURE', (string)Tools::getValue('PAYPAL_API_SIGNATURE'));

			// social sharing buttons
			Configuration::updateValue('AFFILIATE_FACEBOOK', (int)Tools::getValue('AFFILIATE_FACEBOOK'));
			Configuration::updateValue('AFFILIATE_TWITTER', (int)Tools::getValue('AFFILIATE_TWITTER'));
			Configuration::updateValue('AFFILIATE_GOOGLE', (int)Tools::getValue('AFFILIATE_GOOGLE'));
			Configuration::updateValue('AFFILIATE_DIGG', (int)Tools::getValue('AFFILIATE_DIGG'));

			// saving Discount data
			$discount_status = (int)Tools::getValue('REFERRAL_DISCOUNT_STATUS');

			if (($discount_status) && (Configuration::get('ID_AFFILIATE_DISCOUNT_RULE') == 0))
			{
				if ((float)Tools::getValue('REFERRAL_DISCOUNT_VALUE') < 0.00)
					$this->context->controller->errors[] = $this->l('Invalid discount value');
				else
				{
					$languages = Language::getLanguages();
					$discount = new CartRule();
					foreach ($languages as $lang)
						$discount->name[$lang['id_lang']]	= $this->l('Affiliation Program');

					$discount->date_from = date('Y-m-d H:i:s');
					$discount->date_to = date('Y-m-d H:i:s', strtotime('+5 years'));
					$discount->date_add = date('Y-m-d H:i:s');
					$discount->code = Tools::passwdGen(12, 'ALPHANUMERIC');

					$discount->quantity = 1000;
					$discount->partial_use = 0; 
					$discount->reduction_currency = (int)Tools::getValue('REFERRAL_DISCOUNT_CURRENCY');
					$discount->highlight = 0;
					$discount->group_restriction = 1;


					if (!Validate::isFloat(Tools::getValue('REFERRAL_DISCOUNT_VALUE')))
						$this->context->controller->errors[] = $this->l('Inavlid Discount value value');
					else
					{
						if (Tools::getValue('REFERRAL_DISCOUNT_TYPE') == 'percent')
							$discount->reduction_percent = (float)Tools::getValue('REFERRAL_DISCOUNT_VALUE');
						else
							$discount->reduction_amount = (float)Tools::getValue('REFERRAL_DISCOUNT_VALUE');

						if ($discount->add())
						{
							Configuration::updateValue('ID_AFFILIATE_DISCOUNT_RULE', $discount->id);
							$groups = Group::getGroups((int)$this->context->language->id);
							foreach ($groups as $group)
							{
								if ($group['id_group'] != Configuration::get('ID_AFFILIATE_GROUP'))
									Affiliation::restrictVoucherToAffiliateGroup($discount->id, (int)$group['id_group']);
							}
						}
					}
				}
			}
			elseif ((Configuration::get('ID_AFFILIATE_DISCOUNT_RULE') > 0))
			{
				$discount = new CartRule((int)Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'));
				$discount->active = (int)$discount_status;
				$discount->group_restriction = 1;
				$discount->reduction_currency = (int)Tools::getValue('REFERRAL_DISCOUNT_CURRENCY');

				if ($discount->quantity <= 0)
					$discount->quantity = 1000;
				if (Tools::getValue('REFERRAL_DISCOUNT_TYPE') == 'percent')
					$discount->reduction_percent = (float)Tools::getValue('REFERRAL_DISCOUNT_VALUE');
				else
					$discount->reduction_amount = (float)Tools::getValue('REFERRAL_DISCOUNT_VALUE');

				$discount->date_to = (strtotime($discount->date_to) <= strtotime(date('Y:m:d H:i:s')))? date('Y-m-d H:i:s', strtotime('+5 years')): $discount->date_to;

				if ($discount->update())
				{
					$groups = Group::getGroups((int)$this->context->language->id);
					foreach ($groups as $group)
					{
						if ($group['id_group'] != Configuration::get('ID_AFFILIATE_GROUP'))
							Affiliation::restrictVoucherToAffiliateGroup($discount->id, (int)$group['id_group']);
					}
				}
			}

			Configuration::updateValue('REFERRAL_DISCOUNT_STATUS', (int)$discount_status);
			Configuration::updateValue('REFERRAL_DISCOUNT_TYPE', (string)Tools::getValue('REFERRAL_DISCOUNT_TYPE'));
			Configuration::updateValue('REFERRAL_DISCOUNT_VALUE', (float)Tools::getValue('REFERRAL_DISCOUNT_VALUE'));
			Configuration::updateValue('REFERRAL_DISCOUNT_CURRENCY', (int)Tools::getValue('REFERRAL_DISCOUNT_CURRENCY'));
				
			// saving multilingual message content
			$message_trads = array('referral_welcom_msg' => array());
			foreach ($_POST as $key => $value)
				if (preg_match('/referral_welcom_msg_/i', $key))
				{
					$id_lang = preg_split('/referral_welcom_msg_/i', $key);
					$message_trads['referral_welcom_msg'][(int)$id_lang[1]] = $value;
				}
			Configuration::updateValue('referral_welcom_msg', $message_trads['referral_welcom_msg'], true);

			// Multishop processing
			if (Shop::isFeatureActive())
			{
				$assoc_shops = Tools::getValue('checkBoxShopAsso_affiliate');
				Db::getInstance()->delete('affiliate_shop');
				if (isset($assoc_shops) && $assoc_shops)
				{
					if (Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'))
						Affiliation::deleteShopRestriction(Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'));

					foreach ($assoc_shops as $id_shop)
					{
						Db::getInstance()->insert('affiliate_shop',
							array(
								'id_shop' => (int)$id_shop,
								'id_group' => (int)Shop::getGroupFromShop($id_shop))
							);

						if (Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'))
							Affiliation::restrictVoucherToShop(Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'), $id_shop);
					}
				}
				else
				{
					if (Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'))
					{
						Affiliation::deleteShopRestriction(Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'));
						$shops = Shop::getShops();
						foreach ($shops as $shop)
							Affiliation::restrictVoucherToShop(Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'), $shop['id_shop']);
					}
				}
			}

			if (!$this->context->controller->errors)
				$this->context->controller->confirmations[] = $this->l('Updated Successfully');
		}
	}

	private function renderShops()
	{
		$this->fields_form = array(
			'form' => array(
				'id_form' => 'field_shops',
				'input' => array(
					array(
						'type' => 'shop',
						'label' => $this->l('Shop association:'),
						'name' => 'checkBoxShopAsso',
					),
				)
			)
		);
		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->table = 'affiliate';
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$this->fields_form = array();
		$helper->id = (int)$this->context->employee->id;
		$helper->identifier = 'id_group';
		$helper->tpl_vars = array_merge(array(
				'languages' => Language::getLanguages(),
				'id_language' => $this->context->language->id
			));
		return $helper->renderAssoShop();
	}

	protected function createAffiliateGroup()
	{
		$affiliate_group = new Group();
		$affiliate_group->reduction = 0;
		$affiliate_group->price_display_method = 1;
		$affiliate_group->show_prices = 1;
		$affiliate_group->date_add = date('Y-m-d H:i:s');

		//$id_group = (int)Configuration::get('PS_CUSTOMER_GROUP');
		foreach (Language::getLanguages() as $lang)
			$affiliate_group->name[$lang['id_lang']] = $this->l('Affiliates');

		if ($affiliate_group->add())
		{
			Configuration::updateValue('ID_AFFILIATE_GROUP', $affiliate_group->id);
			Configuration::updateValue('AFFILIATE_GROUPS', Configuration::get('PS_CUSTOMER_GROUP').','.$affiliate_group->id);
			$shops = Shop::getShops(true, null, true);
			$modules = Module::getModulesInstalled();
			$auth_modules_tmp = array();
			foreach ($modules as $val)
				$auth_modules_tmp[] = $val['id_module'];

			Group::addModulesRestrictions((int)Configuration::get('ID_AFFILIATE_GROUP'), $auth_modules_tmp, $shops);

			$categories = Affiliation::getAllCategories();
			foreach ($categories as $id_category)
				Affiliation::addAffiliateGroupToCategory($id_category, (int)Configuration::get('ID_AFFILIATE_GROUP'));

			return true;
		}
		return false;
	}

	public static function deleteAffiliateGroup()
	{
		$affiliate_group = new Group((int)Configuration::get('ID_AFFILIATE_GROUP'));
		if ($affiliate_group->delete())
		{
			Configuration::deleteByName('ID_AFFILIATE_GROUP');
			return true;
		}
		return false;
	}

	protected function deleteDiscountVoucher()
	{
		if (Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'))
		{
			$discount_voucher = new CartRule(Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'));
			if ($discount_voucher->delete())
			{
				Configuration::deleteByName('ID_AFFILIATE_DISCOUNT_RULE');
				return true;
			}
			return false;
		}
		return true;
	}

	public function hookActionAuthentication($params)
	{
		$customer = $params['customer'];
		$cart = $params['cart'];

		if (isset($cart) && $cart)
		{
			$cart_rules = $cart->getCartRules();
			$groups = Customer::getGroupsStatic($customer->id);
			if (isset($cart_rules) && $cart_rules)
			{
				foreach ($cart_rules as $rule)
				{
					if (in_array((int)Configuration::get('ID_AFFILIATE_GROUP'), $groups)
						&& $rule['id_cart_rule'] == Configuration::get('ID_AFFILIATE_DISCOUNT_RULE'))
						$cart->removeCartRule($rule['id_cart_rule']);
				}
			}
		}
	}
}