<?php
/**
* Affiliates
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright © Copyright 2017 - All right reserved
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  FMM Modules
* @package   affiliates
*/

class Levels extends ObjectModel
{
	public $id;
	public $id_level;
	public $reward_type;
	public $reward_value;
	public $is_tax = 0;
	public $is_default = 1;
	public $min_order_value = 0.0;
	public $active = 0;

	public static $definition = array(
		'table' => 'affiliate_levels',
		'primary' => 'id_level',
		'multilang' => false,
		'fields' => array(
			'id_level'			=> array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
			'reward_type'		=> array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
			'reward_value'		=> array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
			'is_tax'			=> array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
			'is_default'		=> array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
			'min_order_value'	=> array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
			'active'			=> array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
		),
	);

	public static function createTable()
	{
		// levels table
		Db::getInstance()->execute('DROP TABLE IF EXISTS '._DB_PREFIX_.'affiliate_levels');
		Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS '._DB_PREFIX_.'affiliate_levels(
					`id_level`			int(11)	unsigned NOT NULL auto_increment,
					`reward_type`		int(11)	unsigned NOT NULL default 0,
					`reward_value`		DECIMAL(20,6),
					`is_tax`			tinyint(1) default 0,
					`is_default`		tinyint(1) default 0,
					`min_order_value`	DECIMAL(20,6) default 0.00,
					`active`			tinyint(1) default 1,
					PRIMARY KEY			(`id_level`)
					) ENGINE=InnoDB		AUTO_INCREMENT=1 DEFAULT CHARSET=utf8');
		return true;
	}

	public static function removeTable()
	{
		return (bool)Db::getInstance()->Execute('DROP TABLE IF EXISTS '._DB_PREFIX_.'affiliate_levels');
	}

	public function add($autodate = true, $null_values = false)
	{
		if (!parent::add($autodate, $null_values))
			return false;
		return true;
	}

	public function update($null_values = false)
	{
		if (parent::update($null_values))
			return true;
		return false;
	}

	public function delete()
	{
		if (parent::delete())
			return true;
		return false;
	}

	public static function countLevels()
	{
		return (int)Db::getInstance()->getValue('SELECT COUNT(`id_level`) FROM `'._DB_PREFIX_.'affiliate_levels`');
	}

	public static function getOneLevel()
	{
		return Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'affiliate_levels`
			WHERE `id_level` = (SELECT MIN(`id_level`) FROM `'._DB_PREFIX_.'affiliate_levels`)');
	}

	public static function getDefaultLevel()
	{
		return Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'affiliate_levels`
			WHERE active = 1');
	}
}