<?php
/**
* Affiliates
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright © Copyright 2017 - All right reserved
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  FMM Modules
* @package   affiliates
*/

class AdminRulesController extends ModuleAdminController
{
	public function __construct()
	{
		$this->table = 'affiliate_rules';
		$this->className = 'Rules';
		$this->identifier = 'id_rule';
		$this->lang = false;
		$this->deleted = false;
		$this->colorOnBackground = false;
		$this->bootstrap = true;
		parent::__construct();
		$this->bulk_actions = array(
			'delete' => array(
				'text' => $this->l('Delete selected'),
				'confirm' => $this->l('Delete selected items?')
				));
		$this->_use_found_rows = true;

		$this->fields_list = array(
			'id_rule'	=> array(
				'title'		=> $this->l('ID'),
				'width'		=> 25
			),
			'min_nb_ref'	=> array(
				'title'		=> $this->l('Min Referrals'),
				'align'		=> 'center',
				'orderby'	=> false
			),
			'max_nb_ref'	=> array(
				'title'		=> $this->l('Max Referrals'),
				'align'		=> 'center',
				'orderby'	=> false
			),
			'reg_reward_value'	=> array(
				'title'		=> $this->l('Reward Value'),
				'type'		=> 'price',
				'align'		=> 'center',
				'orderby'	=> false
			),
			'active'		=> array(
				'title'		=> $this->l('Status'),
				'width'		=> 70,
				'active'	=> 'active',
				'type'		=> 'bool',
				'align'		=> 'center',
				'orderby'	=> false
			)
		);
	}

	public function renderList()
	{
		// Adds an Edit button for each result
		$this->addRowAction('edit');
		// Adds a Delete button for each result
		$this->addRowAction('delete');
		return parent::renderList();
	}

	public function renderForm()
	{
		$back = Tools::safeOutput(Tools::getValue('back', ''));
		$btn_title = $this->l('Save');
		$form_title = $this->l('Add Rule');
		if (empty($back))
			$back = self::$currentIndex.'&token='.$this->token;

		if (Tools::getValue('id_rule'))
		{
			$btn_title = $this->l('Update');
			$form_title = $this->l('Edit Rule');
		}

		$type = 'switch';
		if (Tools::version_compare(_PS_VERSION_, '1.6.0.0', '<'))
			$type = 'radio';

		$this->fields_form = array(
			'tinymce' => true,
			'legend' => array(
				'title' => $form_title,
				'icon' => 'icon-bookmark'
			),
			'input' => array(
				array(
					'type'	=> 'text',
					'col'	=> '2',
					'label' => $this->l('Min referrals'),
					'name'	=> 'min_nb_ref',
					'hint'	=> $this->l('minimum No of referrals to get a reward.'),
					'required'	=> true,
				),
				array(
					'type'	=> 'text',
					'col'	=> '2',
					'label' => $this->l('Max Referrals'),
					'name'	=> 'max_nb_ref',
					'hint'	=> $this->l('default 0 (unlimited)'),
					'desc'	=> $this->l('default 0 (unlimited)'),
					'required'	=> false,
				),
				array(
					'type'		=> 'text',
					'prefix'	=> $this->context->currency->prefix,
					'col'		=> '2',
					'label'		=> $this->l('Reward'),
					'name'		=> 'reg_reward_value',
					'validation' => 'isFloat',
					'cast'		=> 'floatval',
					'required'	=> false,
				),
				array(
					'type'		=> $type,
					'label'		=> $this->l('Status'),
					'name'		=> 'active',
					'required'	=> false,
					'class'		=> 't',
					'is_bool'	=> true,
					'values'	=> array(
						array(
							'id'	=> 'active_on',
							'value'	=> 1,
							'label'	=> $this->l('Enabled')
						),
						array(
							'id'	=> 'active_off',
							'value'	=> 0,
							'label'	=> $this->l('Disabled')
						)
					),
				),
			),
			'submit'	=> array(
				'title'	=> $btn_title,
				),
		);
		return parent::renderForm();
	}

	public function postProcess()
	{
		$c_index = $this->context->link->getAdminLink('AdminRules');
		if (Tools::isSubmit('submitAdd'.$this->table))
		{
			$id_rule = (int)Tools::getValue('id_rule');
			$active = (int)Tools::getValue('active');
			$min_nb_ref = (int)Tools::getValue('min_nb_ref');
			$max_nb_ref = (int)Tools::getValue('max_nb_ref');
			$reg_reward_value = (int)Tools::getValue('reg_reward_value');

			if ($id_rule)
			{
				$rule = new Rules($id_rule);
				$rule->active = $active;
				$rule->min_nb_ref = $min_nb_ref;
				$rule->max_nb_ref = $max_nb_ref;
				$rule->reg_reward_value = $reg_reward_value;
				if ($rule->update())
					Tools::redirectAdmin($c_index.'&conf=4');
				else
					$this->errors[] = Tools::displayError('operation failed');
			}
			else
			{
				$rule = new Rules();
				$rule->active = $active;
				$rule->min_nb_ref = $min_nb_ref;
				$rule->max_nb_ref = $max_nb_ref;
				$rule->reg_reward_value = $reg_reward_value;
				if ($rule->add())
					Tools::redirectAdmin($c_index.'&conf=3');
				else
					$this->errors[] = Tools::displayError('operation failed');
			}
		}

		if (Tools::isSubmit('active'.$this->table))
		{
			$id_rule = (int)Tools::getValue('id_rule');
			if ($id_rule)
			{
				$rule = new Rules($id_rule);
				$rule->active = !$rule->active;
				if ($rule->update())
					Tools::redirectAdmin($c_index.'&conf=4');
				else
					$this->errors[] = Tools::displayError('operation failed');
			}
		}

		if (Tools::isSubmit('delete'.$this->table))
		{
			$id_rule = (int)Tools::getValue('id_rule');
			if ($id_rule)
			{
				$rule = new Rules($id_rule);
				if ($rule->delete())
					Tools::redirectAdmin($c_index.'&conf=1');
				else
					$this->errors[] = Tools::displayError('operation failed');
			}
		}
	}
}
?>