<?php
/**
* Affiliates
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright © Copyright 2017 - All right reserved
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  FMM Modules
* @package   affiliates
*/

class AdminAffiliateStatesController extends ModuleAdminController
{
	public function __construct()
	{
		$this->table = 'affiliate';
		$this->className = 'Affiliation';
		$this->identifier = 'id_affiliate';
		$this->deleted = false;
		$this->bootstrap = true;
		$this->_select = '
		SUM(r.`ord_reward_value`) + SUM(r.`reg_reward_value`) AS total_reward,
		SUM(r.`ord_reward_value`) AS order_reward,
		SUM(r.`reg_reward_value`) AS reg_reward,
		CONCAT(c.`firstname`, \' \', c.`lastname`) AS affiliate';

		$this->_join = '
		INNER JOIN `'._DB_PREFIX_.'affiliate_reward` r ON (r.`id_affiliate` = a.`id_affiliate`)
		LEFT JOIN `'._DB_PREFIX_.'customer` c ON (c.`id_customer` = a.`id_customer`)';
		$this->_group .= 'GROUP BY r.`id_affiliate`';
		$this->_use_found_rows = true;
		parent::__construct();
		$this->fields_list = array(
			'id_affiliate'	=> array(
				'title'		=> $this->l('ID'),
				'width'		=> 25,
			),
			'affiliate'	=> array(
				'title'		=> $this->l('Affiliate'),
				'width'		=> 'auto',
				'class'		=> 'center',
			),
			'order_reward' => array(
				'type'	=> 'price',
				'title'	=> $this->l('Referral Orders Reward'),
				'class' => 'center badge_success',
				'badge_success' => true,
				),
			'reg_reward' => array(
				'type'	=> 'price',
				'title'	=> $this->l('Referral Registrations Reward'),
				'class' => 'center badge_success',
				'badge_success' => true,
				),
			'total_reward' => array(
				'type'	=> 'price',
				'title'	=> $this->l('Total Reward'),
				'class' => 'center badge_success',
				'badge_success' => true,
				),
		);
	}

	public function renderList()
	{
		// Adds an Edit button for each result
		$this->addRowAction('view');
		// Adds a Delete button for each result
		//$this->addRowAction('delete');
		return parent::renderList();
	}

	public function initToolbar()
	{
		parent::initToolbar();
		unset($this->toolbar_btn['new']);
	}

	public function renderView()
	{
		$rewards = array();
		$referrals = array();
		$total = array();
		$referral_rewards = array();
		$rewards_by_month = array();
		$id_affiliate = (int)Tools::getValue('id_affiliate');
		if ($id_affiliate)
		{
			//$curr_reward = new Rewards((int)$id_reward);
			$rewards = Rewards::getAffiliateReferralRewards((int)$id_affiliate);
			$total = Rewards::getTotalReward((int)$id_affiliate);
			$rewards_by_month = Rewards::getRewardsByMonth((int)$id_affiliate);
			$referrals = Referrals::getReferralByAffiliate((int)$id_affiliate);
			$referral_rewards = Rewards::getAffiliateReferralRewards((int)$id_affiliate);
		}
		$token_order = Tools::getAdminToken('AdminOrders'.(int)Tab::getIdFromClassName('AdminOrders').(int)$this->context->employee->id);

		$scale = 0;
		if (isset($total) && $total)
			if ($total['total_by_reg'] || $total['total_by_ord'])
				$scale = (int)ceil($total['total_by_reg'] + $total['total_by_ord']) / 2;

		$scale = ($scale > 0)? $scale : 1;

		$this->context->smarty->assign(
			array(
				'version'			=> _PS_VERSION_,
				'months'			=> $this->getMonths(),
				'rewards_by_month' 	=> $rewards_by_month,
				'currency_prefix'	=> $this->context->currency->prefix,
				'token_order'		=> $token_order,
				'Rewards'			=> $rewards,
				'referrals'			=> $referrals,
				'total_reward'		=> $total,
				'scale'				=> $scale,
				'referral_rewards'	=> $referral_rewards,
			));
		return parent::renderView();
	}

	protected function getMonths()
	{
		return array(
			1	=> $this->l('Jan'),
			2	=> $this->l('Feb'),
			3	=> $this->l('Mar'),
			4	=> $this->l('Apr'),
			5	=> $this->l('May'),
			6	=> $this->l('Jun'),
			7	=> $this->l('Jul'),
			8	=> $this->l('Aug'),
			9	=> $this->l('Sep'),
			10	=> $this->l('Oct'),
			11	=> $this->l('Nov'),
			12	=> $this->l('Dec')
		);
	}

	public function setMedia()
	{
		parent::setMedia();
		$this->addCSS(_PS_MODULE_DIR_.'affiliates/views/css/accordion.css');
		$this->context->controller->addJqueryUI(array('ui.accordion'));
		$this->context->controller->addJS(_PS_MODULE_DIR_.'affiliates/views/js/graph.js');
		//$this->addJS(_PS_MODULE_DIR_.'affiliates/views/js/jquery.accordion.js');
	}
}