<?php
/**
* Affiliates
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright © Copyright 2017 - All right reserved
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  FMM Modules
* @package   affiliates
*/

class AdminLevelsController extends ModuleAdminController
{
	public function __construct()
	{
		$this->table = 'affiliate_levels';
		$this->className = 'Levels';
		$this->identifier = 'id_level';
		$this->lang = false;
		$this->deleted = false;
		$this->bootstrap = true;
		parent::__construct();
		$this->_select = 'a.id_level, a.is_tax, a.active, IF(a.reward_type = 0, "'.$this->l('Fixed').'", "'.$this->l('% of Total Order').'") as type';
		$this->_use_found_rows = true;
		$this->fields_list = array(
			'id_level'	=> array(
				'title'		=> $this->l('ID'),
				'width'		=> 25
			),
			'type'	=> array(
				'type'		=> 'text',
				'title'		=> $this->l('Reward Type'),
				'align'		=> 'center',
				'type'		=> 'price'
			),
			'reward_value' => array(
				'title'		=> $this->l('Value')
				),
			'is_tax'		=> array(
				'title'		=> $this->l('Tax Incl.'),
				'active'	=> 'is_tax',
				'type'		=> 'bool',
				'align'		=> 'center',
				'orderby'	=> false
			),
			'active'		=> array(
				'title'		=> $this->l('Status'),
				'width'		=> 70,
				'active'	=> 'active',
				'type'		=> 'bool',
				'align'		=> 'center',
				'orderby'	=> false
			)
		);
	}

	public function renderList()
	{		// Adds an Edit button for each result
		$this->addRowAction('edit');
		return parent::renderList();
	}

	public function initToolbar()
	{
		$nbr_levels = Levels::countLevels();
		$this->toolbar_title[] = $this->l('Order Reward');
		parent::initToolbar();
		if ($nbr_levels >= 1)
			unset($this->toolbar_btn['new']);
	}

	public function renderForm()
	{
		$back = Tools::safeOutput(Tools::getValue('back', ''));
		$btn_title = $this->l('Save');
		$form_title = (($id_level = (int)Tools::getValue('id_level')) == 0)? $this->l('Add Order Reward') : $this->l('Edit Order Reward');
		if (empty($back))
			$back = self::$currentIndex.'&token='.$this->token;

		if ($id_level)
		{
			$btn_title = $this->l('Update');
			$form_title = $this->l('Edit Level');
		}

		$type = 'switch';
		if (Tools::version_compare(_PS_VERSION_, '1.6.0.0', '<'))
			$type = 'radio';

		$this->fields_form = array(
			'tinymce' => true,
			'legend' => array(
				'title' => $form_title,
				'icon' => 'icon-list'
			),
			'input' => array(
				array(
					'type' => $type,
					'label' => $this->l('Status'),
					'name' => 'active',
					'required' => false,
					'class' => 't',
					'is_bool' => true,
					'values' => array(
						array(
							'id' => 'active_on',
							'value' => 1,
							'label' => $this->l('Enabled')
						),
						array(
							'id' => 'active_off',
							'value' => 0,
							'label' => $this->l('Disabled')
						)
					),
				),
				array(
					'type'	=> 'select',
					'label'	=> $this->l('Reward Type'),
					'name'	=> 'reward_type',
					'options' => array(
						'query'	=> array(
							array(
								'id_option' => 0,
								'name' => $this->l('Fixed')
								),
							array(
								'id_option' => 1,
								'name' => $this->l('Percentage of Total Order')
								),
							),
						'id'	=> 'id_option',
						'name'	=> 'name'
						),
					),
				array(
					'type' => 'hidden',
					'name' => 'reward_value'
					),
				array(
					'type' => 'text',
					'prefix' => $this->context->currency->prefix,
					'col' => '2',
					'label' => $this->l('Reward amount'),
					'id'	=> 'amount-value',
					'name' => 'reward_value_0',
					'required' => false,
				),
				array(
					'type' => 'text',
					'prefix' => '%',
					'col' => '2',
					'id'	=> 'pc-value',
					'label' => $this->l('Value'),
					'name' => 'reward_value_1',
					'required' => false,
				),
				array(
					'type'	=> 'select',
					'label'	=> $this->l('Tax'),
					'name'	=> 'is_tax',
					'options' => array(
						'query'	=> array(
							array(
								'id_option' => 0,
								'name' => $this->l('Tax excl.')
								),
							array(
								'id_option' => 1,
								'name' => $this->l('Tax Incl.')
								),
							),
						'id'	=> 'id_option',
						'name'	=> 'name'
						)
					),
				array(
					'type' => 'text',
					'prefix' => $this->context->currency->prefix,
					'col' => '2',
					'label' => $this->l('Min Order Value'),
					'name' => 'min_order_value',
					'required' => false,
				),
			),
			'submit' => array(
				'title' => $btn_title,
				),
		);
		return parent::renderForm();
	}

	public function postProcess()
	{
		$c_index = $this->context->link->getAdminLink('AdminLevels');
		if (Tools::isSubmit('submitAdd'.$this->table))
		{
			$id_level = (int)Tools::getValue('id_level');
			$active = (int)Tools::getValue('active');
			$reward_type = (int)Tools::getValue('reward_type');
			$reward_value = (float)Tools::getValue('reward_value_'.$reward_type);
			$is_tax = (int)Tools::getValue('is_tax');
			$min_order_value = (float)Tools::getValue('min_order_value');

			if ($id_level)
			{
				$level = new Levels($id_level);
				$level->active = $active;
				$level->reward_type = $reward_type;
				$level->reward_value = $reward_value;
				$level->is_tax = $is_tax;
				$level->min_order_value = $min_order_value;
				if ($level->update())
					Tools::redirectAdmin($c_index.'&conf=4');
				else
					$this->errors[] = Tools::displayError('operation failed');
			}
			else
			{
				$level = new Levels();
				$level->active = $active;
				$level->reward_type = $reward_type;
				$level->reward_value = $reward_value;
				$level->is_tax = $is_tax;
				$level->min_order_value = $min_order_value;
				if ($level->add())
					Tools::redirectAdmin($c_index.'&conf=3');
				else
					$this->errors[] = Tools::displayError('operation failed');
			}
		}

		if (Tools::isSubmit('active'.$this->table))
		{
			$id_level = (int)Tools::getValue('id_level');
			if ($id_level)
			{
				$level = new Levels($id_level);
				$level->active = !$level->active;
				if ($level->update())
					Tools::redirectAdmin($c_index.'&conf=4');
				else
					$this->errors[] = Tools::displayError('operation failed');
			}
		}

		if (Tools::isSubmit('is_tax'.$this->table))
		{
			$id_level = (int)Tools::getValue('id_level');
			if ($id_level)
			{
				$level = new Levels($id_level);
				$level->is_tax = !$level->is_tax;
				if ($level->update())
					Tools::redirectAdmin($c_index.'&conf=4');
				else
					$this->errors[] = Tools::displayError('operation failed');
			}
		}

		if (Tools::isSubmit('delete'.$this->table))
		{
			$id_level = (int)Tools::getValue('id_level');
			if ($id_level)
			{
				$level = new Levels($id_level);
				if ($level->delete())
					Tools::redirectAdmin($c_index.'&conf=1');
				else
					$this->errors[] = Tools::displayError('operation failed');
			}
		}
	}
}
?>