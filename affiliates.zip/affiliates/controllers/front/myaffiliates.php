<?php
/**
* Affiliates
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
*
* @author    FMM Modules
* @copyright © Copyright 2017 - All right reserved
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
* @category  FMM Modules
* @package   affiliates
*/

class AffiliatesMyAffiliatesModuleFrontController extends ModuleFrontController
{
	public $error = '';
	public function __construct()
	{
		parent::__construct();
		$this->display_column_left = false;
		$this->display_column_right = false;
		$this->context = Context::getContext();
	}

	public function initContent()
	{
		parent::initContent();
		$id_customer = (int)$this->context->customer->id;

		$affiliate = Affiliation::getAffiliateByCustomer($id_customer);
		$request = '';
		$pdetails = '';
		$payment_request = '';
		$active_tab = '#affiliation_tab_1';
		$base_url = $this->context->shop->getBaseURL(false);

		if (!defined('_PS_BASE_URL_SSL_'))
			$base_url = $this->context->shop->getBaseURL(true);

		$ref_key_link = $base_url.'?src=link&ref='.$affiliate['ref_key'];
		$ref_key_email = $base_url.'?src=email&ref='.$affiliate['ref_key'];

		$url_link = $ref_key_link;
		$url_email = $ref_key_email;

		if (!($this->context->customer->logged))
			Tools::redirect($this->context->link->getPageLink('my-account'));
		
		// affiliation request
		if (Tools::isSubmit('sendAffiliateRequest'))
		{
			if (!empty($affiliate))
				$request = 'already sent';
			else
			{
				$affiliation = new Affiliation();
				$affiliation->id_customer = (int)$id_customer;
				$affiliation->id_guest = (int)$this->context->cookie->id_guest;
				$affiliation->ref_key = Tools::passwdGen((Configuration::get('REFERAK_KEY_LEN')? (int)Configuration::get('REFERAK_KEY_LEN') : 16), 'ALPHANUMERIC');
				$affiliation->active = 1;
				$affiliation->approved = 0;
				$affiliation->date_from = date('Y-m-d H:i:s');

				if ($affiliation->add())
				{
					$request = 'request success';
					// sending customer affiliate request to store admin
					if (Configuration::get('PS_SHOP_EMAIL') && Validate::isEmail(Configuration::get('PS_SHOP_EMAIL')))
					{
						$vars = array(
								'{email}' => (string)$this->context->customer->email,
								'{lastname}' => (string)$this->context->customer->lastname,
								'{firstname}' => (string)$this->context->customer->firstname,
								'{req_date}' => date('Y-m-d H:i:s'),
								);

						Mail::Send((int)$this->context->language->id,
								'affiliation_request',
								Mail::l('New affiliation request', (int)$this->context->language->id),
								$vars,
								Configuration::get('PS_SHOP_EMAIL'),
								null,
								null,
								null,
								null,
								null,
								dirname(__FILE__).'/../../mails/',
								false);
					}
				}
				else
					$request = 'request failed';
			}
		}

		// Mailing invitation to referral sponsor
		$invitation_sent = false;
		$nb_invitation = 0;
		if (Tools::isSubmit('inviteReferral') && Tools::getValue('referralEmail') && count($referral_email = Tools::getValue('referralEmail')) >= 1)
		{
			$active_tab = '#affiliation_tab_1';

			if (!Tools::getValue('conditionsValided'))
				$this->error = 'conditions not valided';
			else
			{
				$referral_last_name = Tools::getValue('referralLastName');
				$referral_first_name = Tools::getValue('referralFirstName');
				$mails_exists = array();

				foreach ($referral_email as $key => $ref_email)
				{
					$ref_email = (string)$ref_email;
					$ref_lastname = (string)$referral_last_name[$key];
					$ref_firstname = (string)$referral_first_name[$key];

					if (empty($ref_email) && empty($ref_lastname) && empty($ref_firstname))
						continue;
					elseif (empty($ref_email) || !Validate::isEmail($ref_email))
						$this->error = 'email invalid';
					elseif (empty($ref_firstname) || empty($ref_lastname) || !Validate::isName($ref_lastname) || !Validate::isName($ref_firstname))
						$this->error = 'name invalid';
					elseif (AffiliateInvitations::isEmailExists($ref_email) || Customer::customerExists($ref_email))
						$mails_exists[] = $ref_email;
					else
					{
						$aff_customer = Affiliation::getAffiliateByCustomer((int)$id_customer);

						$referral = new AffiliateInvitations();
						$referral->id_affiliate = (int)$aff_customer['id_affiliate'];
						$referral->firstname = $ref_firstname;
						$referral->lastname = $ref_lastname;
						$referral->email = $ref_email;
						$referral->id_customer = (int)$id_customer;
						$referral->date_add = date('Y:m:d H:i:s');

						if (!$referral->validateFields(false))
							$this->error = 'name invalid';
						else
						{
							if ($referral->add())
							{
								$vars = array(
									'{email}' => (string)$this->context->customer->email,
									'{lastname}' => (string)$this->context->customer->lastname,
									'{firstname}' => (string)$this->context->customer->firstname,
									'{email_referral}' => $ref_email,
									'{lastname_referral}' => $ref_lastname,
									'{firstname_referral}' => $ref_firstname,
									'{link}' => $url_email.'&inv='.((int)$referral->id).'&t='.md5((string)$ref_email),
									'{message}' => (Tools::getValue('ref_msg')? Tools::getValue('ref_msg'): '')
									);
								Mail::Send((int)$this->context->language->id,
									'referral_invitation',
									Mail::l('You got an Invitation', (int)$this->context->language->id),
									$vars,
									$ref_email,
									$ref_firstname.' '.$ref_lastname,
									(string)Configuration::get('PS_SHOP_EMAIL'),
									(string)Configuration::get('PS_SHOP_NAME'),
									null,
									null,
									dirname(__FILE__).'/../../mails/',
									false,
									1);
								$invitation_sent = true;
								$nb_invitation++;
							}
							else
								$this->error = 'cannot add referrals';
						}
					}

					if ($this->error)
						break;
				}

				if ($nb_invitation > 0)
					unset($_POST);

				//Not to stop the sending of e-mails in case of doubloon
				if (count($mails_exists))
					$this->error = 'email exists';
			}
		}

		// Mailing revive
		$revive_sent = false;
		$nb_revive = 0;
		if (Tools::isSubmit('reviveReferral'))
		{
			$active_tab = '#affiliation_tab_2';
			if (Tools::getValue('referralChecked') && count($referrals_checked = Tools::getValue('referralChecked')) >= 1)
			{
				foreach ($referrals_checked as $id_invitation)
				{
					if (AffiliateInvitations::isSponsorReferral((int)$id_customer, (int)$id_invitation))
					{
						$referral = new AffiliateInvitations((int)$id_invitation);
						$vars = array(
							'{email}' => $this->context->customer->email,
							'{lastname}' => $this->context->customer->lastname,
							'{firstname}' => $this->context->customer->firstname,
							'{email_referral}' => $referral->email,
							'{lastname_referral}' => $referral->lastname,
							'{firstname_referral}' => $referral->firstname,
							'{link}' =>  $url_email.'&inv='.((int)$referral->id).'&t='.md5((string)$referral->email)
							// '{discount}' => $discount
						);
						$referral->date_upd = date('Y-m-d H:i:s');
						$referral->update();
						Mail::Send((int)$this->context->language->id,
							'referral_invitation',
							Mail::l('You got an Invitation', (int)$this->context->language->id),
							$vars,
							$referral->email,
							$referral->firstname.' '.$referral->lastname,
							(string)Configuration::get('PS_SHOP_EMAIL'),
							(string)Configuration::get('PS_SHOP_NAME'),
							null,
							null,
							dirname(__FILE__).'/../../mails/',
							false,
							1);
						$revive_sent = true;
						$nb_revive++;
					}
				}
			}
			else
				$this->error = 'no revive checked';
		}

		if (Tools::isSubmit('withdraw'))
		{
			$active_tab = '#affiliation_tab_4';
			$requested_payments = Tools::getValue('valid_rewards');
			$payment_type = (int)Tools::getValue('payment_detail');

			$payment_details = PaymentDetails::getPaymentDetailsByMethod((int)$affiliate['id_affiliate'], $payment_type);
			if (empty($payment_details) || !isset($payment_details))
				$payment_request = 'no_payment_method';
			if (!isset($requested_payments) || !$requested_payments)
				$payment_request = 'no_amount';
			else
			{
				//$payment_type = (int)Configuration::get('PAYMENT_METHOD');
				foreach ($requested_payments as $id_reward)
				{
					$reward = new Rewards((int)$id_reward);
					$prev_request = Payment::getPaymentByReward($id_reward, $reward->id_affiliate);
					if (isset($prev_request))
						$prev_request['type'] = (int)$prev_request['type'];

					if ($reward->pay_request == 'accepted')
						$payment_request = 'paid';
					elseif ($reward->pay_request == 'pending' && isset($prev_request) && $prev_request['type'] == $payment_type)
						$payment_request = 'request_already_sent';
					elseif ($reward->pay_request == 'cancelled' && isset($prev_request) && $prev_request['type'] == $payment_type)
						$payment_request = 'request_cancelled';
					elseif ($payment_type && isset($prev_request) && $prev_request['type'] != $payment_type && isset($prev_request['id_payment']))
					{
						$reward->pay_request = 'pending';

						$payment = new Payment((int)$prev_request['id_payment']);
						$payment->type = (int)$payment_type;
						$payment->details = (string)$payment_details;
						$payment->status = 'pending';
						$payment->requested_date = date('Y-m-d H:i:s');
						$payment->upd_date = date('Y-m-d H:i:s');

						if ($payment->update() && $reward->update())
							$payment_request = 'request_success';
						else
							$payment_request = 'request_error';
					}
					else
					{
						$reward->pay_request = 'pending';

						$payment = new Payment();
						$payment->id_reward = (int)$id_reward;
						$payment->id_affiliate = (int)$reward->id_affiliate;
						$payment->type = (int)$payment_type;
						$payment->details = (string)$payment_details;
						$payment->status = 'pending';
						$payment->requested_date = date('Y-m-d H:i:s');

						if ($payment->add() && $reward->update())
							$payment_request = 'request_success';
						else
							$payment_request = 'request_error';
					}
				}
			}
			Tools::redirect($this->context->link->getModuleLink('affiliates', 'myaffiliates', array('payment_request' => $payment_request)));
		}

		if (Tools::isSubmit('paymentDetails'))
		{
			$active_tab = '#affiliation_tab_5';
			$payment_details = Tools::getValue('payment_details');
			if (!isset($payment_details) || !$payment_details)
				$pdetails = 'empty details';
			else
			{
				foreach ($payment_details as $type => $detail)
				{
					$id_detail = (int)PaymentDetails::getPaymentIdByType((int)$affiliate['id_affiliate'], $type);
					if (!empty($id_detail))
					{
						$pd = new PaymentDetails($id_detail);
						$pd->upd_date = date('Y-m-d H:i:s');
					}
					else
					{
						$pd = new PaymentDetails();
						$pd->date_add = date('Y-m-d H:i:s');
					}
							
					// if ($type == 1 && !Validate::isEmail($detail))
					// 	$pdetails = 'invalid email';
					// else
					{
						$pd->type = (int)$type;
						$pd->details = (string)$detail;
						$pd->id_affiliate = (int)$affiliate['id_affiliate'];
						if (!empty($id_detail) && $pd->update())
							$pdetails = 'details saved';
						elseif ($pd->add())
							$pdetails = 'details saved';
						else
							$pdetails = 'details error';
					}
				}
			}
		}

		$total_rewards		= Rewards::getCustomerTotalApprovedReward((int)$id_customer);
		$total_paid			= Rewards::getCustomerTotalPaidRewards((int)$id_customer);
		$pending_rewards	= Rewards::getCustomerPendingRewards((int)$id_customer);
		$awaiting_payments	= Rewards::getCustomerAwaitingPayments($id_customer);
		$av_balance			= (float)($total_rewards - $total_paid - $pending_rewards - $awaiting_payments);

		$rewards = Rewards::getCustomerRewards((int)$id_customer);
		$valid_rewards = Rewards::getCustomerValidRewards($id_customer);

		$cms_link = '';
		if (Configuration::getGlobalValue('AFFILIATE_CONDITION'))
			$cms_link = new CMS((int)Configuration::getGlobalValue('AFFILIATE_CONDITION'), $this->context->cookie->id_lang);
		$ps_17 = (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) ? 1 : 0;
		$this->context->smarty->assign(array(
			'error'					=> $this->error,
			'invitation_sent'		=> $invitation_sent,
			'revive_sent'			=> $revive_sent,
			'nbRevive'				=> $nb_revive,
			'ref_link'				=> (!empty($url_link)) ? $url_link : '',
			'nbInvitation'			=> $nb_invitation,
			'affiliations'			=> $affiliate,
			'request'				=> $request,
			'ps_version'			=> _PS_VERSION_,
			'total_rewards'			=> $total_rewards,
			'total_paid'			=> $total_paid,
			'rewards'				=> $rewards,
			'pdetails'				=> $pdetails,
			'valid_rewards'			=> $valid_rewards,
			'pending_rewards'		=> $pending_rewards,
			'cms'					=> $cms_link,
			'av_balance'			=> ((isset($av_balance) && $av_balance > 0.00)? $av_balance : 0.00),
			'payment_request'		=> $payment_request,
			'awaiting_payments'		=> $awaiting_payments,
			'PAYMENT_METHOD'		=> (Configuration::getGlobalValue('PAYMENT_METHOD')? explode(',', Configuration::get('PAYMENT_METHOD')): ''),
			'PAYMENT_DELAY_TIME'	=> Configuration::getGlobalValue('PAYMENT_DELAY_TIME'),
			'MINIMUM_AMOUNT'		=> Configuration::getGlobalValue('MINIMUM_AMOUNT'),
			'DELAY_TYPE' 			=> Configuration::getGlobalValue('DELAY_TYPE'),
			'active_tab'			=> (($active_tab)? $active_tab : ''),
			'currencySign'			=> $this->context->currency->sign,
			'currencyRate'			=> $this->context->currency->conversion_rate,
			'currencyFormat'		=> $this->context->currency->format,
			'currencyBlank'			=> $this->context->currency->blank,
			'mails_exists'			=> (isset($mails_exists) ? $mails_exists : array()),
			'pendingReferrals'		=> AffiliateInvitations::getPendingInvitations((int)$id_customer),
			'myReferrals'			=> Referrals::getApprovedReferralsByCustomer((int)$id_customer),
			'bankwire_details'		=> PaymentDetails::getPaymentDetailByType($affiliate['id_affiliate'], 2),
			'paypal_details'		=> PaymentDetails::getPaymentDetailByType($affiliate['id_affiliate'], 1),
			'AFFILIATE_FACEBOOK'	=> Configuration::getGlobalValue('AFFILIATE_FACEBOOK'),
			'AFFILIATE_TWITTER'		=> Configuration::getGlobalValue('AFFILIATE_TWITTER'),
			'AFFILIATE_GOOGLE'		=> Configuration::getGlobalValue('AFFILIATE_GOOGLE'),
			'AFFILIATE_DIGG'		=> Configuration::getGlobalValue('AFFILIATE_DIGG'),
		));
		if ($ps_17 > 0)
		{
			$this->context->smarty->assign('errors', $this->error);
			$this->context->smarty->assign(array('base_dir' => _PS_BASE_URL_.__PS_BASE_URI__));
			$this->setTemplate('module:affiliates/views/templates/front/affiliations-17.tpl');
		}
		else
			$this->setTemplate('affiliations.tpl');
	}

	public function setMedia()
	{
		parent::setMedia();
		$this->addJqueryPlugin('fancybox');
		if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true)
		{
			$this->addCSS(_PS_BASE_URL_.__PS_BASE_URI__.'modules/affiliates/views/css/affiliate_tabcontent.css');
			$this->addJS(_PS_BASE_URL_.__PS_BASE_URI__.'modules/affiliates/views/js/affiliate_tabcontent.js');
		}
	}
}
